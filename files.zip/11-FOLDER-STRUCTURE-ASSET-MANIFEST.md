# Folder Structure & Asset Manifest

## Where your uploaded/upcoming assets go in the repo

```
/public
  /models
    brain-hologram.glb        <- converted from scene.gltf (Draco-compressed)
    space-warp.glb             <- converted from Unity2Skfb.gltf (Draco-compressed)
    auto-expo-vehicle.glb      <- [MISSING] source and add — see 06-3D-ASSETS-SCENE-PLAN.md
    pacman.glb / pacman-sprites/  <- from your cloned Pacman repo — point Antigravity at the actual repo path
    ghost.glb / ghost-sprites/    <- same source as above
  /brochures
    abhiyantriki-2025-proposal.pdf
    abhiyantriki-2026-proposal.pdf
  /brand
    council-logo.svg           <- [PENDING] swap in once available; text wordmark fallback until then
  /gallery-seed (optional, only if pre-seeding historical photos rather than uploading via admin panel)
    2017/ 2018/ ... 2024/

/src
  /components
    /three            (R3F scene components: HeroScene, BrainHologram, WarpTunnel, etc.)
    /ui                (buttons, cards, nav, form inputs — Tailwind-based)
    /admin             (admin-only panel components)
    /loader            (Pacman loading sequence)
  /pages or /routes    (Hero, Overview, HighlightEvents, Dignitaries, Archive, Register, Login, Dashboard, Admin)
  /hooks               (useScrollTrigger helpers, useAuth, useGalleryUpload)
  /lib
    supabaseClient.ts
    gsapSetup.ts
  /content             (JSON/TS files holding the structured brochure content from 05-SITE-MAP-CONTENT.md — keep copy data out of components so council members can edit facts without touching code)
    events.ts
    dignitaries.ts
    sponsors.ts
    archive-years.ts

/server (if custom Express backend instead of using Supabase client directly from frontend)
  /routes
  /middleware (auth, admin-check, rate-limit)
  /db (schema/migrations)
```

## Pre-processing steps before Antigravity touches the models

1. Install `gltf-transform` CLI: `npm install -g @gltf-transform/cli`
2. Convert + compress:
   ```
   gltf-transform optimize scene.gltf public/models/brain-hologram.glb --compress draco
   gltf-transform optimize Unity2Skfb.gltf public/models/space-warp.glb --compress draco
   ```
3. Check final file sizes — flag to the team if either exceeds ~3MB after compression; may need to reduce particle count (Brain Hologram) or mesh complexity (the ~30 "Velocidad" speed-line meshes in the warp rig — consider consolidating these into a single instanced mesh rather than 30 separate draw calls).

## Content-as-data principle

Everything in `05-SITE-MAP-CONTENT.md` (dignitary names, sponsor lists, event descriptions, sponsorship tiers) should live in the `/src/content/*.ts` files as structured data, **not hardcoded inside JSX components**. This means:
- Non-technical council members can update a name/date by editing a data file (or eventually a CMS table) without touching animation code.
- The `[NEED]` items flagged in `05-SITE-MAP-CONTENT.md` (confirmed dates, current General Secretary name, final Google Form URLs) can be filled in later without a rebuild of the 3D/scroll code.
