# Master Prompt — paste this to Antigravity as your opening message

---

I'm building the official website for **Abhiyantriki**, the annual technical fest of K. J. Somaiya School of Engineering (KJSSE), run by the Students' Council. This is a real, high-profile college fest — it hosts all three Indian armed forces branches, ISRO, BARC, IMD, an Auto Expo, robotics/humanoid exhibits, hackathons, and a distinguished lecture series that's hosted names like Dr. APJ Abdul Kalam and the Dalai Lama. The site needs to feel cinematic and high-production, not like a generic college club page.

I've prepared a full spec pack in the `spec/` folder of this project. **Before writing any code, read every file in `spec/` in this order** — they contain the actual design direction, tech decisions, real content (pulled from our sponsorship brochures), asset inventory, animation choreography, and backend/security requirements. Don't invent content or architecture decisions that contradict what's in these files:

1. `spec/00-INDEX.md` — overview and known gaps
2. `spec/02-CREATIVE-DIRECTION.md` — the visual/tonal direction and why
3. `spec/03-TECH-STACK-ARCHITECTURE.md` — exact stack to use
4. `spec/04-DESIGN-SYSTEM-COLOR-TYPE.md` — color/type/motion tokens
5. `spec/05-SITE-MAP-CONTENT.md` — every section and its real copy/content
6. `spec/06-3D-ASSETS-SCENE-PLAN.md` — what the 3D models actually are and where they go
7. `spec/07-SCROLL-LOADER-ANIMATION-SPEC.md` — the Pacman loader + full scroll choreography, section by section
8. `spec/08-AUTH-BACKEND-DATABASE.md` — auth, roles, and DB schema
9. `spec/09-ADMIN-CMS-GOOGLE-FORMS.md` — admin panel + Google Forms embedding
10. `spec/10-SECURITY-CHECKLIST.md` — security requirements, non-negotiable before launch
11. `spec/11-FOLDER-STRUCTURE-ASSET-MANIFEST.md` — exact repo layout and asset prep steps

## Assets provided alongside this spec

- `scene.gltf` — Brain Hologram particle model
- `Unity2Skfb.gltf` — space warp/vortex tunnel rig with a small ship ("Nave") and thruster ("Propulsor")
- Two brochure documents (Abhiyantriki 2025 and 2026 sponsorship proposals) — source of the site's real content
- Reference site for scroll/motion feel: **gustavobatista.dev** — study its pinned-section, scroll-driven 3D storytelling pattern, but do not copy its layout; our sitemap is richer (see `05-SITE-MAP-CONTENT.md`)
- Two color palette references ("Arctic Depths" and "DecorNovaa") — already converted into tokens in `04-DESIGN-SYSTEM-COLOR-TYPE.md`, use those tokens directly
- [I will add:] the council logo, a cloned Pacman GitHub repo for loader assets, and a vehicle model for the Auto Expo section — flag clearly in your output anywhere you're using a placeholder for one of these so I know what to swap later

## What to build, in order

**Phase 1 — Foundation**
- Scaffold the Vite + React + Tailwind + TypeScript project per `03-TECH-STACK-ARCHITECTURE.md` and `11-FOLDER-STRUCTURE-ASSET-MANIFEST.md`.
- Set up the Tailwind theme with the tokens from `04-DESIGN-SYSTEM-COLOR-TYPE.md`.
- Run the asset pre-processing steps in `11-FOLDER-STRUCTURE-ASSET-MANIFEST.md` (convert/compress the two `.gltf` files to `.glb`).

**Phase 2 — Loader + Hero**
- Build the Pacman loading sequence exactly per `07-SCROLL-LOADER-ANIMATION-SPEC.md` Part A, including the real-progress tie-in, skip control, and reduced-motion fallback.
- Build the Hero section (Part B, row 1 of the table).

**Phase 3 — Main scroll experience**
- Build each remaining pinned section from the choreography table in `07-SCROLL-LOADER-ANIMATION-SPEC.md`, using the real content from `05-SITE-MAP-CONTENT.md`.
- Implement the mobile/`matchMedia` fallback behavior described there — this is required, not optional polish.
- Implement the reduced-motion and low-end-device static fallback path from `03-TECH-STACK-ARCHITECTURE.md`.

**Phase 4 — Functional layer**
- Set up Supabase project, apply the schema from `08-AUTH-BACKEND-DATABASE.md`, implement RLS policies.
- Build login/register, the student dashboard, and the native event registration flow.
- Build the Google Form embed component and wire `events.google_form_url` as described in `09-ADMIN-CMS-GOOGLE-FORMS.md`.
- Build the `/admin` panel (events manager, gallery manager, registrants view, admin users) per the same file.

**Phase 5 — Hardening**
- Work through every item in `10-SECURITY-CHECKLIST.md` and report back on each one — don't mark anything done without actually verifying it (e.g. actually test that student A can't read student B's registration via a direct API call).

## Ground rules

- Where a spec file marks something `[NEED]` or flags a gap (missing logo, missing vehicle model, unconfirmed dates), **do not guess** — build with a clearly-labeled placeholder and tell me explicitly what you need from me.
- Prioritize the site working well and fast on a mid-range Android phone on campus wifi over maximal visual fidelity — the registration flow is the actual job-to-be-done during fest week; the 3D scroll experience is what gets people excited beforehand.
- Ask me before making any architecture decision not already covered in these files (e.g. if you think Next.js is actually better than Vite for a reason not addressed in `03-TECH-STACK-ARCHITECTURE.md`, raise it — don't silently switch).

Start with Phase 1 and show me the scaffolded structure before moving to Phase 2.
