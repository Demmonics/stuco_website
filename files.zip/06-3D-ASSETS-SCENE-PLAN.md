# 3D Asset Inventory & Scene Plan

## What you actually have (verified from the uploaded files themselves)

| File | What it actually is | Source |
|---|---|---|
| `scene.gltf` | **Brain Hologram** — a particle-based icosphere brain model (glowing dot-cloud brain), by Sketchfab artist "oxterium" | Sketchfab, standard license |
| `Unity2Skfb.gltf` | **Space warp/vortex rig** — nodes named "Dizzy Space," "Vortex," "Nave" (ship), "Propulsor" (thruster), and ~30 "Velocidad" (speed-line) meshes — this is a hyperspace-jump / warp-tunnel effect with a small ship, not a motorcycle | Exported from Unity |

Correction for the record: earlier description of this asset as a "motorcycle" was based on a misread — no vehicle model exists in your uploads. The screenshots you attached (`16.png`, `18.png`, `21.png`, `Screenshot_2026-09-11_103322.png`) are duplicate screenshots of the gustavobatista.dev reference site, not a 3D asset browser — they contain no model list. Plan around the two models above only, plus whatever you add from the Pacman repo.

## Where each model actually fits the site

**Brain Hologram → Ideate / hackathon / robotics sections.** A glowing particle brain reads immediately as "AI/innovation" — perfect for the Ideate competition section (real industry problem statements) or a robotics/hackathon section header. Don't put it in the hero; save it for the section where "engineering intelligence" is the point.

**Space Warp/Vortex rig → the scroll-transition device between major sections, and/or the hero.** This is the best use of it: trigger the "Velocidad" speed-line burst + vortex as a **transition effect when the user scrolls between two major sections** (e.g. leaving Overview into Highlight Events) — a 1–2 second "jump to warp" moment, GSAP-triggered, not something sitting idle on screen. Its small ship ("Nave") can also work as the literal vehicle "flying" the camera through the site if you want a recurring first-person conceit (camera rides inside/behind the Nave for the whole scroll journey) — this is a strong option if you want one consistent visual thread tying the whole scroll together instead of a different one-off model per section.

## Gaps to fill

1. **Auto Expo model** — no vehicle exists yet. Options, cheapest to most effort:
   - Use real photos of the BMW M5/Goldwing/etc. instead of 3D (fastest, zero risk).
   - Source one free-license low-poly motorcycle/car glTF from Sketchfab (filter: Downloadable + CC license) for a single hero shot in that section — don't need photorealism, this fest's whole visual language is stylized/hologram-like, so a low-poly or wireframe bike fits better than attempting photoreal anyway.
2. **Pacman assets** — you mentioned a cloned Pacman GitHub repo. Give Antigravity the actual repo path/asset folder so it reuses the real Pacman + ghost meshes/sprites for the loader (see `07-SCROLL-LOADER-ANIMATION-SPEC.md`) instead of building new ones from scratch.
3. **Council logo** — not yet supplied; site should ship with a text wordmark fallback (`ABHIYANTRIKI` in the display font) until the logo file arrives, and swap via one config value, not a code change.

## Technical handling for all models

- Convert every `.gltf` to compressed `.glb` (Draco compression) before use — see performance budget in `03-TECH-STACK-ARCHITECTURE.md`. The Brain Hologram's particle system especially will be heavy uncompressed; compress and also consider capping particle count if frame rate drops on mid-range phones.
- Load via `@react-three/drei`'s `useGLTF`, with `useGLTF.preload()` called only when the section is about to scroll into view (intersection observer), not all on initial page load.
- Every model needs a **2D static fallback image** (a rendered screenshot of the model) for the reduced-motion/low-end path described in `03-TECH-STACK-ARCHITECTURE.md`.
