# Abhiyantriki Website — Spec Pack Index

This folder is a complete build brief for the Abhiyantriki (KJSSE Students' Council tech fest) website. It's written to be handed to an AI coding agent (Antigravity) along with your asset files.

## How to use this with Antigravity

1. Create a new project folder. Drop in:
   - This entire `spec/` folder
   - Your 3D models: `scene.gltf` (Brain Hologram) and `Unity2Skfb.gltf` (Space Warp/Vortex rig)
   - The two brochure files (PDF or DOCX — "Abhiyantriki 2025 Sponsorship Proposal" and "Abhiyantriki 2026 hybrid deck")
   - The council logo (once you have it exported as SVG/PNG)
2. Open `01-MASTER-AGENT-PROMPT.md` — copy its full contents as your first message to Antigravity. It references every other file in this folder by name, so keep the folder structure intact.
3. Let Antigravity read the other files as it works — don't paste all 12 at once, it'll pull them in as needed because the master prompt tells it to open each file before starting the relevant part of the build.

## File map

| File | What it's for |
|---|---|
| `01-MASTER-AGENT-PROMPT.md` | The actual prompt to give Antigravity. Start here. |
| `02-CREATIVE-DIRECTION.md` | The "why" — mood, references, what NOT to do |
| `03-TECH-STACK-ARCHITECTURE.md` | Framework, libraries, project structure, deployment |
| `04-DESIGN-SYSTEM-COLOR-TYPE.md` | Colors, type, spacing, motion tokens |
| `05-SITE-MAP-CONTENT.md` | Every page/section + real content pulled from your brochures |
| `06-3D-ASSETS-SCENE-PLAN.md` | What each 3D model is, where it's used, what's missing |
| `07-SCROLL-LOADER-ANIMATION-SPEC.md` | Pacman loader + GSAP ScrollTrigger choreography, section by section |
| `08-AUTH-BACKEND-DATABASE.md` | Login/register, schema, session handling |
| `09-ADMIN-CMS-GOOGLE-FORMS.md` | Admin panel for event photos + embedding Google Forms |
| `10-SECURITY-CHECKLIST.md` | Pre-launch security pass |
| `11-FOLDER-STRUCTURE-ASSET-MANIFEST.md` | Exact repo layout, where every asset file goes |

## Known gaps you still need to close before/while building

- **No motorcycle/vehicle 3D model was actually uploaded.** Your screenshots were duplicates of the gustavobatista.dev reference site — not an asset browser. Source a free-license bike/vehicle glTF (Sketchfab, "downloadable" + CC license filter) for the Auto Expo section, or swap that section to photos instead of 3D.
- **Pacman model/sprite set** — you mentioned cloning a Pacman repo; point Antigravity at that repo's asset folder path once you've added it, so it can reuse the actual meshes/sprites instead of building placeholders.
- **Council logo** — not yet uploaded. Site can ship with a text wordmark first and swap it in later; don't block the build on this.
- **Google Form URLs** — you'll need the actual embed links for each event before the registration section is functional; a placeholder embed is fine for now.
